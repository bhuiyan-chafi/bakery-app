--
-- PostgreSQL database dump
--

\restrict FYEpSgjghxregOVGtqY4A14kHRxBHHE9WcNuX15DkClWmnORcO3R59ore06z5a7

-- Dumped from database version 15.17
-- Dumped by pg_dump version 17.10 (Debian 17.10-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: admin
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO admin;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: admin
--

COMMENT ON SCHEMA public IS '';


--
-- Name: categorystatus; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.categorystatus AS ENUM (
    'ACTIVE',
    'INACTIVE'
);


ALTER TYPE public.categorystatus OWNER TO admin;

--
-- Name: discounttype; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.discounttype AS ENUM (
    'amount',
    'percent'
);


ALTER TYPE public.discounttype OWNER TO admin;

--
-- Name: orderstatus; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.orderstatus AS ENUM (
    'pending',
    'complete',
    'cancelled'
);


ALTER TYPE public.orderstatus OWNER TO admin;

--
-- Name: ordertype; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.ordertype AS ENUM (
    'shop',
    'pickup',
    'delivery'
);


ALTER TYPE public.ordertype OWNER TO admin;

--
-- Name: productionstatus; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.productionstatus AS ENUM (
    'pending',
    'running',
    'completed'
);


ALTER TYPE public.productionstatus OWNER TO admin;

--
-- Name: producttransactiontype; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.producttransactiontype AS ENUM (
    'IN',
    'OUT'
);


ALTER TYPE public.producttransactiontype OWNER TO admin;

--
-- Name: transactionstatus; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.transactionstatus AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public.transactionstatus OWNER TO admin;

--
-- Name: transactiontype; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.transactiontype AS ENUM (
    'IN',
    'OUT'
);


ALTER TYPE public.transactiontype OWNER TO admin;

--
-- Name: userpermissionstatus; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.userpermissionstatus AS ENUM (
    'ACTIVE',
    'INACTIVE'
);


ALTER TYPE public.userpermissionstatus OWNER TO admin;

--
-- Name: userrole; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.userrole AS ENUM (
    'ADMIN',
    'MANAGER',
    'STAFF',
    'NORMAL'
);


ALTER TYPE public.userrole OWNER TO admin;

--
-- Name: userstatus; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.userstatus AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'SUSPENDED',
    'PENDING',
    'APPROVED'
);


ALTER TYPE public.userstatus OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: inventory; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.inventory (
    uuid character varying(36) NOT NULL,
    name character varying(100) NOT NULL,
    unit_uuid character varying(36) NOT NULL,
    quantity_alert double precision NOT NULL
);


ALTER TABLE public.inventory OWNER TO admin;

--
-- Name: inventory_transactions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.inventory_transactions (
    uuid character varying(36) NOT NULL,
    inventory_uuid character varying(36) NOT NULL,
    quantity double precision NOT NULL,
    transaction_type public.transactiontype NOT NULL,
    cost double precision NOT NULL,
    datetime timestamp without time zone NOT NULL,
    status public.transactionstatus NOT NULL,
    supplier text
);


ALTER TABLE public.inventory_transactions OWNER TO admin;

--
-- Name: miscellaneous_transactions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.miscellaneous_transactions (
    id integer NOT NULL,
    uuid character varying(36) NOT NULL,
    transaction_type character varying(50) NOT NULL,
    transaction_on character varying(15) NOT NULL,
    amount double precision NOT NULL,
    transaction_date date NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.miscellaneous_transactions OWNER TO admin;

--
-- Name: miscellaneous_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.miscellaneous_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.miscellaneous_transactions_id_seq OWNER TO admin;

--
-- Name: miscellaneous_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.miscellaneous_transactions_id_seq OWNED BY public.miscellaneous_transactions.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.order_items (
    uuid character varying(36) NOT NULL,
    order_uuid character varying(36) NOT NULL,
    product_uuid character varying(36) NOT NULL,
    quantity double precision NOT NULL,
    unit_price double precision NOT NULL,
    line_total double precision NOT NULL
);


ALTER TABLE public.order_items OWNER TO admin;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.orders (
    uuid character varying(36) NOT NULL,
    order_number character varying(20) NOT NULL,
    customer_name character varying(150) NOT NULL,
    phone character varying(30),
    address text,
    order_type public.ordertype NOT NULL,
    assigned_to character varying(80),
    status public.orderstatus NOT NULL,
    discount_type public.discounttype NOT NULL,
    discount_value double precision NOT NULL,
    discount_amount double precision NOT NULL,
    subtotal double precision NOT NULL,
    total double precision NOT NULL,
    notes text,
    sold_by character varying(80),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.orders OWNER TO admin;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.permissions (
    uuid character varying(36) NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.permissions OWNER TO admin;

--
-- Name: product_categories; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.product_categories (
    uuid character varying(36) NOT NULL,
    name character varying(100) NOT NULL,
    parent character varying(36) NOT NULL,
    status public.categorystatus NOT NULL
);


ALTER TABLE public.product_categories OWNER TO admin;

--
-- Name: product_transactions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.product_transactions (
    uuid character varying(36) NOT NULL,
    product_uuid character varying(36) NOT NULL,
    production_uuid character varying(36),
    transaction_type public.producttransactiontype NOT NULL,
    quantity double precision NOT NULL,
    created_at timestamp without time zone NOT NULL,
    notes text
);


ALTER TABLE public.product_transactions OWNER TO admin;

--
-- Name: productions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.productions (
    uuid character varying(36) NOT NULL,
    product_uuid character varying(36) NOT NULL,
    recipe_uuid character varying(36) NOT NULL,
    batch_quantity double precision NOT NULL,
    damaged_quantity double precision NOT NULL,
    status public.productionstatus NOT NULL,
    produced_at timestamp without time zone,
    notes text
);


ALTER TABLE public.productions OWNER TO admin;

--
-- Name: products; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.products (
    uuid character varying(36) NOT NULL,
    name character varying(100) NOT NULL,
    category_uuid character varying(36) NOT NULL,
    price double precision NOT NULL,
    stock_threshold double precision NOT NULL
);


ALTER TABLE public.products OWNER TO admin;

--
-- Name: recipe_ingredients; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.recipe_ingredients (
    uuid character varying(36) NOT NULL,
    recipe_uuid character varying(36) NOT NULL,
    inventory_uuid character varying(36) NOT NULL,
    quantity double precision NOT NULL
);


ALTER TABLE public.recipe_ingredients OWNER TO admin;

--
-- Name: recipes; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.recipes (
    uuid character varying(36) NOT NULL,
    product_uuid character varying(36) NOT NULL,
    name character varying(100) NOT NULL,
    instructions text
);


ALTER TABLE public.recipes OWNER TO admin;

--
-- Name: unit_measurements; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.unit_measurements (
    uuid character varying(36) NOT NULL,
    name character varying(100) NOT NULL,
    measurement character varying(50) NOT NULL
);


ALTER TABLE public.unit_measurements OWNER TO admin;

--
-- Name: user_details; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.user_details (
    uuid character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    name character varying(100),
    phone character varying(20),
    address text
);


ALTER TABLE public.user_details OWNER TO admin;

--
-- Name: user_permissions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.user_permissions (
    uuid character varying(36) NOT NULL,
    user_uuid character varying(36) NOT NULL,
    permission_uuid character varying(36) NOT NULL,
    status public.userpermissionstatus NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.user_permissions OWNER TO admin;

--
-- Name: users; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.users (
    uuid character varying(36) NOT NULL,
    username character varying(80) NOT NULL,
    password_hash character varying(128) NOT NULL,
    role public.userrole NOT NULL,
    status public.userstatus NOT NULL,
    last_login timestamp without time zone,
    created_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO admin;

--
-- Name: miscellaneous_transactions id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.miscellaneous_transactions ALTER COLUMN id SET DEFAULT nextval('public.miscellaneous_transactions_id_seq'::regclass);


--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.inventory (uuid, name, unit_uuid, quantity_alert) FROM stdin;
4078c2f7-14e6-42b6-8595-5f4709ebb5ff	Flour	0e7dd728-de58-427e-acc4-4986eaa30e6b	50
25e2afdd-846f-460c-86ff-0625f1034bb8	Milk	ffb7281b-94ef-4ecd-aab4-55f9cd8659f6	10
5b0b43fd-5aa9-4a7d-9ff7-e3bbded6144c	Sugar	0e7dd728-de58-427e-acc4-4986eaa30e6b	10
ba0dee41-c43f-459c-9455-ce300feefc85	Eggs	848abfa3-e13c-4b86-8950-7147ad0561df	100
\.


--
-- Data for Name: inventory_transactions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.inventory_transactions (uuid, inventory_uuid, quantity, transaction_type, cost, datetime, status, supplier) FROM stdin;
e3400e73-0556-4c58-a61c-6296fb3cfa01	ba0dee41-c43f-459c-9455-ce300feefc85	1000	IN	0.2	2026-07-31 10:27:11.138169	APPROVED	\N
83e45dd3-5c91-47e8-bffb-84ab1fda30d9	5b0b43fd-5aa9-4a7d-9ff7-e3bbded6144c	50	IN	1.5	2026-07-31 10:26:57.53582	APPROVED	\N
60d8a3db-fdf3-43db-b40b-d0074aaf6f4c	25e2afdd-846f-460c-86ff-0625f1034bb8	100	IN	0.5	2026-07-31 10:26:44.654963	APPROVED	\N
70af8a82-e0e5-4436-b909-18bc5421f949	4078c2f7-14e6-42b6-8595-5f4709ebb5ff	500	IN	1	2026-07-31 10:26:29.314698	APPROVED	\N
28cc50f2-f829-471c-b2e7-e076d9c2984b	4078c2f7-14e6-42b6-8595-5f4709ebb5ff	200	OUT	0	2026-07-31 10:30:18.570749	APPROVED	\N
2bb5f366-e90d-491d-b3c9-09df3affb6f5	25e2afdd-846f-460c-86ff-0625f1034bb8	50	OUT	0	2026-07-31 10:30:18.57076	APPROVED	\N
d495998f-89a4-4a84-a342-a921b9e35e58	ba0dee41-c43f-459c-9455-ce300feefc85	1000	OUT	0	2026-07-31 10:30:18.570767	APPROVED	\N
51bc2cb2-b293-40dc-aafe-44cd84e92af8	5b0b43fd-5aa9-4a7d-9ff7-e3bbded6144c	10	OUT	0	2026-07-31 10:30:18.570776	APPROVED	\N
beac437d-c482-4e4e-a208-56c12417a893	ba0dee41-c43f-459c-9455-ce300feefc85	1000	IN	200	2026-07-31 10:31:54.147084	APPROVED	\N
\.


--
-- Data for Name: miscellaneous_transactions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.miscellaneous_transactions (id, uuid, transaction_type, transaction_on, amount, transaction_date, created_at) FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.order_items (uuid, order_uuid, product_uuid, quantity, unit_price, line_total) FROM stdin;
e5cef91f-5b92-4167-b47b-c2135bafff03	5f8d049b-40fc-4085-9080-06fb2c173463	d5cf1163-9c63-4b17-87b8-2013539dde2e	10	1.5	15
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.orders (uuid, order_number, customer_name, phone, address, order_type, assigned_to, status, discount_type, discount_value, discount_amount, subtotal, total, notes, sold_by, created_at, updated_at) FROM stdin;
5f8d049b-40fc-4085-9080-06fb2c173463	ORD-Q5NVP7	ASM CHAFIULLAH BHUIYAN	+393533299790	Praticelli, Via Berchet 40, località Ghezzano, 56017 40	delivery	driver	complete	amount	0	0	15	15	Fragile Items	admin	2026-07-31 10:39:34.311267	2026-07-31 10:40:03.200282
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.permissions (uuid, name) FROM stdin;
\.


--
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.product_categories (uuid, name, parent, status) FROM stdin;
cdc405bf-e4b3-4214-9105-b569a0ab8dbc	Bread	0	ACTIVE
\.


--
-- Data for Name: product_transactions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.product_transactions (uuid, product_uuid, production_uuid, transaction_type, quantity, created_at, notes) FROM stdin;
c4f27a21-6598-448b-ab22-69987fb2a903	d5cf1163-9c63-4b17-87b8-2013539dde2e	cfe7a768-77b9-4a98-965a-3ad45a0e2919	IN	990	2026-07-31 10:30:54.133527	Auto-created on production completion
\.


--
-- Data for Name: productions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.productions (uuid, product_uuid, recipe_uuid, batch_quantity, damaged_quantity, status, produced_at, notes) FROM stdin;
cfe7a768-77b9-4a98-965a-3ad45a0e2919	d5cf1163-9c63-4b17-87b8-2013539dde2e	e77a39ad-c7bb-4222-9071-412c658d62ad	1000	10	completed	2026-07-31 10:30:54.132072	\N
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.products (uuid, name, category_uuid, price, stock_threshold) FROM stdin;
d5cf1163-9c63-4b17-87b8-2013539dde2e	White Bread	cdc405bf-e4b3-4214-9105-b569a0ab8dbc	1.5	10
\.


--
-- Data for Name: recipe_ingredients; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.recipe_ingredients (uuid, recipe_uuid, inventory_uuid, quantity) FROM stdin;
140d4bbb-4603-4a80-b34c-c3fec7fa3081	e77a39ad-c7bb-4222-9071-412c658d62ad	4078c2f7-14e6-42b6-8595-5f4709ebb5ff	0.2
058e908f-d79a-426c-87cd-8c5c5e7ffb8b	e77a39ad-c7bb-4222-9071-412c658d62ad	25e2afdd-846f-460c-86ff-0625f1034bb8	0.05
a7ad5cec-4cc6-425c-ac5a-92fb8e9c970f	e77a39ad-c7bb-4222-9071-412c658d62ad	ba0dee41-c43f-459c-9455-ce300feefc85	1
18d56cb7-1280-4720-bcc6-94e8a81f48ca	e77a39ad-c7bb-4222-9071-412c658d62ad	5b0b43fd-5aa9-4a7d-9ff7-e3bbded6144c	0.01
\.


--
-- Data for Name: recipes; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.recipes (uuid, product_uuid, name, instructions) FROM stdin;
e77a39ad-c7bb-4222-9071-412c658d62ad	d5cf1163-9c63-4b17-87b8-2013539dde2e	White Bread	For one bread
\.


--
-- Data for Name: unit_measurements; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.unit_measurements (uuid, name, measurement) FROM stdin;
0e7dd728-de58-427e-acc4-4986eaa30e6b	Kilograms	kg
ffb7281b-94ef-4ecd-aab4-55f9cd8659f6	Litre	lt
848abfa3-e13c-4b86-8950-7147ad0561df	Pieces	pcs
\.


--
-- Data for Name: user_details; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.user_details (uuid, user_id, name, phone, address) FROM stdin;
f6e8c178-b247-4f2a-8c28-3d95402facf0	fcd45d25-bd4c-4913-ace9-1f07215e7e13	ASM CHAFIULLAH BHUIYAN	3533299790	Praticelli, Via Berchet 40, località Ghezzano, 56017 40
9c309693-05d8-40a3-8e8f-18a6fe9776c8	efdb822f-26b3-4fba-98e0-b4e6f76b77d6	Test Driver 1		
\.


--
-- Data for Name: user_permissions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.user_permissions (uuid, user_uuid, permission_uuid, status, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.users (uuid, username, password_hash, role, status, last_login, created_at) FROM stdin;
efdb822f-26b3-4fba-98e0-b4e6f76b77d6	driver	$2b$12$FZ9FRLeCSpyIFOpqf4x86eU.sz/9//w3KZE0Bsz/zBGPyTZA3dILm	NORMAL	ACTIVE	2026-07-31 10:34:25.814956	2026-07-31 10:33:48.48403
fcd45d25-bd4c-4913-ace9-1f07215e7e13	admin	$2b$12$/Dbji0PFc5X7TdhbZWnJZegfS5TZrHweYqNvIMSQuYMO7aFqPuJZa	ADMIN	ACTIVE	2026-07-31 10:39:01.501322	2026-07-31 09:59:57.841905
\.


--
-- Name: miscellaneous_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.miscellaneous_transactions_id_seq', 1, false);


--
-- Name: inventory inventory_name_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_name_key UNIQUE (name);


--
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (uuid);


--
-- Name: inventory_transactions inventory_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_pkey PRIMARY KEY (uuid);


--
-- Name: miscellaneous_transactions miscellaneous_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.miscellaneous_transactions
    ADD CONSTRAINT miscellaneous_transactions_pkey PRIMARY KEY (id);


--
-- Name: miscellaneous_transactions miscellaneous_transactions_uuid_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.miscellaneous_transactions
    ADD CONSTRAINT miscellaneous_transactions_uuid_key UNIQUE (uuid);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (uuid);


--
-- Name: orders orders_order_number_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_order_number_key UNIQUE (order_number);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (uuid);


--
-- Name: permissions permissions_name_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_key UNIQUE (name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (uuid);


--
-- Name: product_categories product_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_pkey PRIMARY KEY (uuid);


--
-- Name: product_transactions product_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.product_transactions
    ADD CONSTRAINT product_transactions_pkey PRIMARY KEY (uuid);


--
-- Name: productions productions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.productions
    ADD CONSTRAINT productions_pkey PRIMARY KEY (uuid);


--
-- Name: products products_name_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_name_key UNIQUE (name);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (uuid);


--
-- Name: recipe_ingredients recipe_ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_pkey PRIMARY KEY (uuid);


--
-- Name: recipes recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_pkey PRIMARY KEY (uuid);


--
-- Name: unit_measurements unit_measurements_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.unit_measurements
    ADD CONSTRAINT unit_measurements_pkey PRIMARY KEY (uuid);


--
-- Name: recipes uq_recipe_product_name; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT uq_recipe_product_name UNIQUE (product_uuid, name);


--
-- Name: user_permissions uq_user_permission; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT uq_user_permission UNIQUE (user_uuid, permission_uuid);


--
-- Name: user_details user_details_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.user_details
    ADD CONSTRAINT user_details_pkey PRIMARY KEY (uuid);


--
-- Name: user_details user_details_user_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.user_details
    ADD CONSTRAINT user_details_user_id_key UNIQUE (user_id);


--
-- Name: user_permissions user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_pkey PRIMARY KEY (uuid);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (uuid);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: inventory_transactions inventory_transactions_inventory_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_inventory_uuid_fkey FOREIGN KEY (inventory_uuid) REFERENCES public.inventory(uuid);


--
-- Name: inventory inventory_unit_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_unit_uuid_fkey FOREIGN KEY (unit_uuid) REFERENCES public.unit_measurements(uuid);


--
-- Name: order_items order_items_order_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_uuid_fkey FOREIGN KEY (order_uuid) REFERENCES public.orders(uuid);


--
-- Name: order_items order_items_product_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_uuid_fkey FOREIGN KEY (product_uuid) REFERENCES public.products(uuid);


--
-- Name: product_transactions product_transactions_product_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.product_transactions
    ADD CONSTRAINT product_transactions_product_uuid_fkey FOREIGN KEY (product_uuid) REFERENCES public.products(uuid);


--
-- Name: product_transactions product_transactions_production_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.product_transactions
    ADD CONSTRAINT product_transactions_production_uuid_fkey FOREIGN KEY (production_uuid) REFERENCES public.productions(uuid);


--
-- Name: productions productions_product_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.productions
    ADD CONSTRAINT productions_product_uuid_fkey FOREIGN KEY (product_uuid) REFERENCES public.products(uuid);


--
-- Name: productions productions_recipe_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.productions
    ADD CONSTRAINT productions_recipe_uuid_fkey FOREIGN KEY (recipe_uuid) REFERENCES public.recipes(uuid);


--
-- Name: products products_category_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_uuid_fkey FOREIGN KEY (category_uuid) REFERENCES public.product_categories(uuid);


--
-- Name: recipe_ingredients recipe_ingredients_inventory_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_inventory_uuid_fkey FOREIGN KEY (inventory_uuid) REFERENCES public.inventory(uuid);


--
-- Name: recipe_ingredients recipe_ingredients_recipe_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_recipe_uuid_fkey FOREIGN KEY (recipe_uuid) REFERENCES public.recipes(uuid);


--
-- Name: recipes recipes_product_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_product_uuid_fkey FOREIGN KEY (product_uuid) REFERENCES public.products(uuid);


--
-- Name: user_details user_details_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.user_details
    ADD CONSTRAINT user_details_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(uuid);


--
-- Name: user_permissions user_permissions_permission_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_permission_uuid_fkey FOREIGN KEY (permission_uuid) REFERENCES public.permissions(uuid);


--
-- Name: user_permissions user_permissions_user_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_user_uuid_fkey FOREIGN KEY (user_uuid) REFERENCES public.users(uuid);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: admin
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict FYEpSgjghxregOVGtqY4A14kHRxBHHE9WcNuX15DkClWmnORcO3R59ore06z5a7

